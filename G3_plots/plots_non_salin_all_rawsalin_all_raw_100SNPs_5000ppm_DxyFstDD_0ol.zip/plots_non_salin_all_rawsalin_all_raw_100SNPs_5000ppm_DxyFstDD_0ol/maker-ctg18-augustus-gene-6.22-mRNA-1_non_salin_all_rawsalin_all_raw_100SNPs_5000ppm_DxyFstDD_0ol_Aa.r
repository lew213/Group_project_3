# load libraries
library(ggplot2)
library(grid)
library(grid)
f <- read.table("/Users/lewiswood/Desktop/project3datanew/Divergence_Scan-master/Lyrata2genesOriented.out",header=F)
locus="maker-ctg18-augustus-gene-6.22-mRNA-1"
winsize = 50000
graphwindow <- winsize/1000*2
locstart <- subset(f[,3], as.vector(f[,1])==locus)
locend <- subset(f[,4], as.vector(f[,1])==locus)
middle=(locend+locstart)/2
locstart <- subset(f[,3], as.vector(f[,1])==locus)
locend <- subset(f[,4], as.vector(f[,1])==locus)
middle=(locend+locstart)/2
start=middle-winsize
end=middle+winsize
genes=subset(f, (f[,2]==k & f[,3]>=start & f[,3]<=end) | (f[,2]==k & f[,4]>=start & f[,4]<=end))
genes$geneor <- ifelse(genes[,5]=="+","last","first")

# the path will be read in by -i
ts25 <- read.csv("/Users/lewiswood/Desktop//Users/lewiswood/Desktop/non_salin_all_rawsalin_all_rawnon_salin_all_rawsalin_all_raw_100SNPs_5000ppm_allsites_Aa.csv", header=T, stringsAsFactor=F)
# for the scaffolds, the beginning of the name has to be evaluated first, best by the python script
s25 <- subset(ts25[ts25$scaffold=="scaffold_k", ])
scafk <- read.table("/Users/lewiswood/Desktop//Users/lewiswood/Desktop/non_salin_all_rawsalin_all_rawnon_salin_all_rawsalin_all_raw_scaf_k_AFs_Aa.table", header=T)
# read in descriptive stats table
descr <- read.table("/Users/lewiswood/Desktop//Users/lewiswood/Desktop/non_salin_all_rawsalin_all_rawnon_salin_all_rawsalin_all_raw_100SNPs_5000ppm_descriptive_stats_Aa.txt", header=T)
# select subsets around locus
sr25 <- s25[s25$start >= start & s25$end <=end,]
scafk$rawAFD_2 <- scafk$AC1/scafk$AN1 - scafk$AC2/scafk$AN2
scafk_sub <- scafk[scafk$POS >= start & scafk$POS <=end,]

# switch to R only here
layout <- theme_bw(base_size=10, base_family="Helvetica") +
   theme(axis.title.x = element_blank(),
   axis.text.x = element_blank(),
   axis.ticks.x = element_blank(),
   panel.grid = element_blank())

layouttix <- theme_bw(base_size=10, base_family="Helvetica") +
   theme(axis.title.x = element_blank(),
   panel.grid = element_blank())

pafds <- ggplot(aes(POS, rawAFD_2), data=scafk_sub) + ylab("AFDsnp") +
   ggtitle(locus) +
   scale_y_continuous(limits=c(-1,1.1)) +
   geom_point(alpha=0.35, size=0.5) +
layouttix
   for(j in 1:nrow(genes)){
   pafds <- pafds + geom_segment(x=genes[j,3], xend=genes[j,4], y=1.1, yend=1.1, colour="grey30",
   arrow=arrow(length=unit(0.02,"npc"), ends=genes[j,"geneor"]))
}
p.AFDs <- pafds  + geom_segment(x=genes[which(genes[,1]==locus), 3],
   xend=genes[which(genes[,1]==locus), 4], y=1.1, yend=1.1, color="red", arrow=arrow(length=unit(0.03, "npc"),
   ends=genes[which(genes[,1]==locus),"geneor"]))

pdxy <- qplot(start, Dxy, data=sr25, geom="line", ylim=c(0,1)) +
   geom_rect(aes(xmin=genes[which(genes[,1]==locus), 3], xmax=genes[which(genes[,1]==locus), 4], ymin=-Inf, ymax=Inf), fill="grey90") +
   geom_line(color=I("green")) +
   geom_hline(yintercept=descr[which(descr$stat=="Cutoff"), "Dxy"], color="green", linetype=2) +
   layout
pfst <- qplot(start, Fst, data=sr25, geom="line", ylim=c(0, 1)) +
   geom_rect(aes(xmin=genes[which(genes[,1]==locus), 3], xmax=genes[which(genes[,1]==locus), 4],
   ymin=-Inf, ymax=Inf), fill="grey90") +
   geom_line(color=I("blue")) +
   geom_hline(yintercept=descr[which(descr$stat=="Cutoff"), "Fst"], color="blue", linetype=2) +
   layout
p.Fst <- pfst  + geom_segment(x=genes[which(genes[,1]==locus), 3], xend=genes[which(genes[,1]==locus), 4],
   y=1, yend=1, color="red", arrow=arrow(length=unit(0.03, "npc"), ends=genes[which(genes[,1]==locus),"geneor"]))

p.Dxy <- pdxy  + geom_segment(x=genes[which(genes[,1]==locus), 3], xend=genes[which(genes[,1]==locus), 4],
   y=1, yend=1, color="red", arrow=arrow(length=unit(0.03, "npc"), ends=genes[which(genes[,1]==locus), "geneor"]))

pdd <- qplot(start, DD, data=sr25, geom="line", ylim=c(-1, 1 )) +
   geom_rect(aes(xmin=genes[which(genes[,1]==locus), 3], xmax=genes[which(genes[,1]==locus), 4],
   ymin=-Inf, ymax=Inf), fill="grey90") +
   geom_line(color=I("goldenrod")) +
   geom_hline(yintercept=descr[which(descr$stat=="Cutoff"), "DD"], color="goldenrod", linetype=2) +
   layout
p.DD <- pdd  + geom_segment(x=genes[which(genes[,1]==locus), 3], xend=genes[which(genes[,1]==locus), 4],
   y=25, yend=25, color="red", arrow=arrow(length=unit(0.03, "npc"), 
   ends=genes[which(genes[,1]==locus),"geneor"]))

pafdw <- ggplot(aes(start, non_salin_all_raw_salin_all_raw), data=sr25) + ylab("AFDwin") +
   scale_y_continuous(limits=c(-1,1.1)) +
   geom_rect(aes(xmin=genes[which(genes[,1]==locus), 3], xmax=genes[which(genes[,1]==locus), 4],
   ymin=-Inf, ymax=Inf), fill="grey90") +
   geom_point(color="red", size=0.5) +
   geom_hline(yintercept=descr[which(descr$stat=="Cutoff"), "AFD_1_2"], color="red", linetype=2) +
   geom_hline(yintercept=descr[which(descr$stat=="Cutoff2"), "AFD_1_2"], color="red", linetype=2) +
   layout
p.AFDw <- pafdw  + geom_segment(x=genes[which(genes[,1]==locus), 3], xend=genes[which(genes[,1]==locus), 4],
   y=1.1, yend=1.1, color="red", arrow=arrow(length=unit(0.03, "npc"),
   ends=genes[which(genes[,1]==locus),"geneor"]))

pdf("/Users/lewiswood/Desktop/non_salin_all_rawsalin_all_rawgenes/plots_non_salin_all_rawsalin_all_raw_100SNPs_5000ppm_DxyFstDD_0ol/maker-ctg18-augustus-gene-6.22-mRNA-1_non_salin_all_rawsalin_all_raw_100SNPs_5000ppm_DxyFstDD_0ol_100kb_Aa.pdf", width=4, height=8)
grid.newpage()
pushViewport(viewport(layout = grid.layout(6,1)))
# define number of columns and rows for the graph #
vplayout <- function(x,y)
   viewport(layout.pos.row=x,layout.pos.col=y)
# specifiy which plot goes where #
print(p.AFDs, vp=vplayout(1:2,1))
print(p.Dxy, vp=vplayout(3,1))
print(p.Fst, vp=vplayout(4,1))
print(p.DD, vp=vplayout(5,1))
print(p.AFDw, vp=vplayout(6,1))
dev.off()