# load table
test <- read.delim("/Users/lewiswood//Users/lewiswood/Desktop/project3datanew/non_saline_indv_pop_pipeline/sol2_metrics_100SNPs_Aa.txt")
#str(test)
#load library
library(ggplot2)
library(methods)
library(grid)
test$pos <- paste(test$scaffold, test$midpoint, sep="-")
p.pi <- qplot(sol2_pi, data=test, binwidth=0.001, xlim=c(0,0.5)) + theme_bw()
p.TajD <- qplot(sol2_TajimasD, data=test, binwidth=0.01, xlim=c(-3, +3)) + theme_bw()
p.length <- qplot(length_bp, data=test, binwidth=100, xlim=c(0,30000)) + theme_bw()

# export as pdf
pdf(file="/Users/lewiswood/Desktop/project3datanew/non_saline_indv_pop_pipeline/graphs/sol2_100SNPs_pi_Aa.pdf")
p.pi
dev.off()
pdf(file="/Users/lewiswood/Desktop/project3datanew/non_saline_indv_pop_pipeline/graphs/sol2_100SNPs_TajimasD_Aa.pdf")
p.TajD
dev.off()
pdf(file="/Users/lewiswood/Desktop/project3datanew/non_saline_indv_pop_pipeline/graphs/sol2_100SNPs_length_Aa.pdf")
p.length
dev.off()

# create overview graph
layout <- theme(legend.position="none", axis.text.x=element_blank())
pgenom <- qplot(pos, sol2_pi, data=test, color=scaffold, ylim=c(0,0.5)) + geom_hline(yintercept=median(test$sol2_pi)) + layout
phist <- p.pi + coord_flip() + theme_bw() + geom_vline(xintercept=median(test$sol2_pi))
pdf("/Users/lewiswood/Desktop/project3datanew/non_saline_indv_pop_pipeline/graphs/sol2_pi.pdf", width=12, height=4)
grid.newpage()
pushViewport(viewport(layout=grid.layout(1,8)))
vplayout <- function(x,y){viewport(layout.pos.row=x, layout.pos.col=y)}
print(pgenom, vp=vplayout(1,1:6))
print(phist, vp=vplayout(1,7:8))
dev.off()
pgenom <- qplot(pos, sol2_TajimasD, data=test, color=scaffold, ylim=c(-3,3)) + geom_hline(yintercept=median(test$sol2_TajimasD)) + layout
phist <- p.TajD + coord_flip() + theme_bw() + geom_vline(xintercept=median(test$sol2_TajimasD))
pdf("/Users/lewiswood/Desktop/project3datanew/non_saline_indv_pop_pipeline/graphs/sol2_TajimasD.pdf", width=12, height=4)
grid.newpage()
pushViewport(viewport(layout=grid.layout(1,8)))
vplayout <- function(x,y){viewport(layout.pos.row=x, layout.pos.col=y)}
print(pgenom, vp=vplayout(1,1:6))
print(phist, vp=vplayout(1,7:8))
dev.off()
pgenom <- qplot(pos, length_bp, data=test, color=scaffold, ylim=c(0,30000)) + geom_hline(yintercept=median(test$length_bp)) + layout
phist <- p.length + coord_flip() + theme_bw() + geom_vline(xintercept=median(test$length_bp))
pdf("/Users/lewiswood/Desktop/project3datanew/non_saline_indv_pop_pipeline/graphs/sol2_length_bp.pdf", width=12, height=4)
grid.newpage()
pushViewport(viewport(layout=grid.layout(1,8)))
vplayout <- function(x,y){viewport(layout.pos.row=x, layout.pos.col=y)}
print(pgenom, vp=vplayout(1,1:6))
print(phist, vp=vplayout(1,7:8))
dev.off()
